
public class Frustration extends Factor{
	public Frustration(){
		super();
		this.title = "Frustration";
	}
}
