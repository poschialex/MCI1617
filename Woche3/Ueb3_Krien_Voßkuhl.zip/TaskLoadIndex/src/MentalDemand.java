
public class MentalDemand extends Factor{
	public MentalDemand(){
		super();
		this.title = "Mental Demand";
	}
}
