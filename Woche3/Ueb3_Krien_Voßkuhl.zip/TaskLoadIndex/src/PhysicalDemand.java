
public class PhysicalDemand extends Factor{
	public PhysicalDemand(){
		super();
		this.title = "Physical Demand";
	}
}
