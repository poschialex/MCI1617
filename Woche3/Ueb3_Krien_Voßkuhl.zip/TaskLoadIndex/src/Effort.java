
public class Effort extends Factor{
	public Effort(){
		super();
		this.title = "Effort";
	}
}
