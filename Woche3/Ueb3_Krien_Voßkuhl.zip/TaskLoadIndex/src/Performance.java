
public class Performance extends Factor{
	public Performance(){
		super();
		this.title = "Performance";
	}
}
