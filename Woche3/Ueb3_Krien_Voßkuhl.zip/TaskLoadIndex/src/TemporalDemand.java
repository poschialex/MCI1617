
public class TemporalDemand extends Factor{
	public TemporalDemand(){
		super();
		this.title = "Temporal Demand";
	}
}
